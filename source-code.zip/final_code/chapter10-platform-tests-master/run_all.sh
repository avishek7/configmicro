#IP Address of the VM Hosting the container
python test_config_server.py
python test_eureka_server.py
python test_zuul_service.py
